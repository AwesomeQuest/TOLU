function y=Df(x)
y=sinh(x).*cos(x)-sin(x).*cosh(x);
end