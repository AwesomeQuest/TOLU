function y = B(t,k,delta,L,omega)
    y = delta/A(L,k,L)*cos(omega*t)
end