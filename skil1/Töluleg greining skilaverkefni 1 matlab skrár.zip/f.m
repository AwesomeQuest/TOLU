function y=f(x)
y= cos(x).*cosh(x)+1;
end