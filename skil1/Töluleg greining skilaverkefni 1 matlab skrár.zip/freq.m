function y=freq(k,EI,lambda)
y=sqrt(abs(k.^4*EI/lambda));
end